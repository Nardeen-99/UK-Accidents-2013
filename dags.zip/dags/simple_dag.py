import pandas as pd
from airflow import DAG,task
from datetime import datetime, timedelta 
from airflow.operators.python import PythonOperator
from datetime import time
import datetime
import csv

def read():
    #df = pd.read_csv('2013_Accidents_UK.csv')
    3+2
    print('ghfjkhgdkj')
    

default_args = {
    'owner': 'Team-2-1',
    'retries': 5,
    'retry_delay': timedelta(minutes=5)
}

with DAG(
    default_args=default_args,
    dag_id='DE-Milestone-40',
    description='Milestone 3 for DE project',
    start_date=datetime.datetime(2023, 1, 17),
    schedule_interval='@once'
) as dag:
    task1 = PythonOperator(
        task_id='readoo', 
        python_callable=read
    )
    
    
    
    task1 