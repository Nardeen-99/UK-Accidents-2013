from airflow import DAG
from datetime import datetime, timedelta 
from airflow.operators.python import PythonOperator
import pandas as pd
import numpy as np
from datetime import time
import datetime
import warnings
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn import preprocessing


columns_data_types = {
    'accident_index': object,
    'accident_year': int,
    'accident_reference': object,
    'location_easting_osgr': int,
    'location_northing_osgr': int,
    'longitude': float,
    'latitude': float,
    'police_force': object,
    'accident_severity': object,
    'number_of_vehicles': int,
    'number_of_casualties': int,
    'day_of_week': object,
    'time': object,
    'local_authority_district': object,
    'local_authority_ons_district': object,
    'local_authority_highway': object,
    'first_road_class': object,
    'first_road_number': object,
    'road_type': object,
    'speed_limit': int,
    'junction_detail': object,
    'junction_control': object,
    'second_road_class': object,
    'second_road_number': object,
    'pedestrian_crossing_human_control': object,
    'pedestrian_crossing_physical_facilities': object,
    'light_conditions': object,
    'weather_conditions': object,
    'road_surface_conditions': object,
    'special_conditions_at_site': object,
    'carriageway_hazards': object,
    'urban_or_rural_area': object,
    'did_police_officer_attend_scene_of_accident': object,
    'trunk_road_flag': object,
    'lsoa_of_accident_location': object
}


def read_csv_file(ti):
    df = pd.read_csv('/opt/airflow/2013/2013_Accidents_UK.csv', parse_dates=['date'], infer_datetime_format=True, \
        dtype=columns_data_types)
    ti.xcom_push(key='raw_dataframe', value=df.to_json())
    
def clean_transform_data(ti):
    #cleaning
    x = ti.xcom_pull(task_ids='read_csv_file', key='raw_dataframe')
    df = pd.read_json(x)
    # df = df.to_csv()
    
    df['first_road_number'] = df['first_road_number'].replace('first_road_class is C or Unclassified. These roads do not have official \
        numbers so recorded as zero ', 0, inplace=True)
    df['second_road_number'] = df['second_road_number'].replace('first_road_class is C or Unclassified. These roads do not have official \
        numbers so recorded as zero ', 0, inplace=True)
    
    df['first_road_number'] = df['first_road_number'].astype(float)
    df['second_road_number'] = df['second_road_number'].astype(float) 
    df['speed_limit'] = df['speed_limit'].astype(int)
    
    df.drop(df[(df['second_road_number'].isna()) & \
                               (df['second_road_class'].notna()) &
                               (df['second_road_class'] != '-1')].index, inplace = True)
    df[['second_road_number']] = df[['second_road_number']].fillna(value=-1, inplace=True)
    #df['second_road_number'] = df['second_road_number'].astype(int)
    df['road_type'] = df['road_type'].fillna(df['speed_limit']. \
                           map(lambda x: 'Single carriageway' if x<70 else 'Dual carriageway'), inplace=True)
    df['trunk_road_flag'] = df['trunk_road_flag'].fillna(df['first_road_class']. \
                           map({'A': 'Non-trunk', 'A(M)': 'Trunk (Roads managed by Highways England)', \
                               'Motorway': 'Trunk (Roads managed by Highways England)', \
                               'B': 'Non-trunk', 'C': 'Non-trunk', 'Unclassified': 'Non-trunk'}), inplace=True)
    df.drop(df[(df['junction_detail'].isna()) & \
                               (df['second_road_class'].notna()) &
                               (df['second_road_class'] != '-1')].index, inplace = True)
    df['junction_detail'] = df['junction_detail'].fillna(value='Not at junction or within 20 metres', inplace=True)
    df['accident_week_number'] = df['date'].dt.isocalendar().week
    weather_groups = df.groupby(['accident_week_number', 'weather_conditions'])['weather_conditions'].count()\
.sort_values(ascending=False)
    week_weather_dict = {}
    for i,j in weather_groups.iteritems():
        if i[0] not in week_weather_dict:
            week_weather_dict[i[0]] = i[1]
    df['weather_conditions'] = df['weather_conditions'].fillna(df['accident_week_number']. \
                           map(week_weather_dict), inplace=True)
    r = df.groupby(['weather_conditions', 'road_surface_conditions'])['road_surface_conditions'].count().sort_values(ascending=False)
    weather_map_dict = {}
    for i,j in r.iteritems():
        if i[0] not in weather_map_dict:
            weather_map_dict[i[0]] = i[1]
    df['road_surface_conditions'] = df['road_surface_conditions'].fillna(df['weather_conditions']. \
                           map(weather_map_dict), inplace=True)
    df.dropna(subset=['did_police_officer_attend_scene_of_accident'], inplace=True)
    df["junction_control"] = np.where(((df["junction_control"].isna()) & \
                    (df['junction_detail'] == 'Not at junction or within 20 metres')) \
                    , 'No junction to control', df['junction_control'])
    junction_detail_control = df.groupby(['junction_detail', 'junction_control'])['junction_control'].count()\
.sort_values(ascending=False)
    junction_d_c_dict = {}
    for i,j in junction_detail_control.iteritems():
        if i[0] not in junction_d_c_dict:
            junction_d_c_dict[i[0]] = i[1]
    df['junction_control'] = df['junction_control'].fillna(df['junction_detail']. \
                           map(junction_d_c_dict), inplace=True)
    df.dropna(subset=['carriageway_hazards'], inplace=True)
    sum(df.duplicated())
    #outliers
    casualtieas = []
    for n in df["number_of_casualties"]:
        if n < 5:
            casualtieas.append("<5")
        elif 5 <= n <= 10:
            casualtieas.append("5-10")
        elif 10 < n <= 15:
            casualtieas.append("10-15")
        elif 15 < n <= 20:
            casualtieas.append("15-20")
        elif 20 < n <= 25:
            casualtieas.append("20-25")
        else:
            casualtieas.append("25 and over")
        
    df["casualties_group"] = casualtieas
    
    vehicles = [] 
    for n in df["number_of_vehicles"]:
        if n < 5:
            vehicles.append("<5")
        elif 5 <= n <= 10:
            vehicles.append("5-10")
        elif 10 < n <= 15:
            vehicles.append("10-15")
        elif 15 < n <= 20:
            vehicles.append("15-20")
        elif 20 < n <= 25:
            vehicles.append("20-25")
        else:
            vehicles.append("25 and over")
        
    df["vehicles_group"] = vehicles
    df_v = df.loc[(df['vehicles_group'] == '10-15') | (df['vehicles_group'] == '25 and over')]
    vehicles_mean = df_v['number_of_vehicles'].mean()
    x = int(round(vehicles_mean, 0))
    df.loc[(df['vehicles_group'] == '10-15') | (df['vehicles_group'] == '25 and over'), 'number_of_vehicles'] = x
    df_c = df.loc[(df['casualties_group'] == '15-20') | (df['casualties_group'] == '25 and over')]
    causalities_mean = df_c['number_of_casualties'].mean()
    y = int(round(causalities_mean, 0))
    df.loc[(df['casualties_group'] == '15-20') | (df['casualties_group'] == '25 and over'), 'number_of_casualties'] = y
    
    #transformation
    df["week_number"] = df["date"].dt.isocalendar().week
    weeks = []
    for n in df["week_number"]:
        if n < 10:
            weeks.append("<10")
        elif 10 <= n <= 20:
            weeks.append("10-20")
        elif 20 < n <= 30:
            weeks.append("20-30")
        elif 30 < n <= 40:
            weeks.append("30-40")
        elif 40 < n <= 50:
            weeks.append("40-50")
        else:
            weeks.append("50-52")
        
    df["week_number"] = weeks
    
    #df['first_road_number'] = df['first_road_number'].astype(int)
    #df['second_road_number'] = df['second_road_number'].astype(int) 
    
    #encoding
    to_be_label_encoded = ['police_force', 'accident_severity', 'local_authority_district', \
                       'local_authority_ons_district', 'local_authority_highway']
    to_be_one_hot_encoded = ['day_of_week', 'first_road_class', 'road_type', 'junction_detail',\
                        'junction_control', 'second_road_class', 'pedestrian_crossing_human_control',\
                        'pedestrian_crossing_physical_facilities', 'light_conditions', 'weather_conditions',\
                        'road_surface_conditions', 'special_conditions_at_site', 'carriageway_hazards', \
                        'urban_or_rural_area', 'did_police_officer_attend_scene_of_accident', 'trunk_road_flag',\
                        'casualties_group', 'vehicles_group', 'week_number']
    for i in to_be_label_encoded:
        df['{}_encoded'.format(i)] = preprocessing.LabelEncoder().fit_transform(df[i])
    
    x = pd.get_dummies(df[to_be_one_hot_encoded])
    for i in x.columns:
        if i not in df:
            df[i] = x[i]
    
    #normalization
    f_road_z_origin = df.first_road_number
    f_road_z_scaled = StandardScaler().fit_transform(df[["first_road_number"]])
    s_road_z_origin = df.second_road_number
    s_road_z_scaled = StandardScaler().fit_transform(df[["second_road_number"]])
    
    df['scaled_first_road_number'] = f_road_z_scaled
    df['scaled_second_road_number'] = s_road_z_scaled
    
    #adding columns
    df_hour = pd.to_datetime(df['time'], format='%H:%M').dt.hour
    df_am_arr = []
    for i in df_hour.values:
        if 0 <= i < 12:
            df_am_arr.append('AM')
        elif 12 <= i < 24:
            df_am_arr.append('PM')
        else:
            df_am_arr.append('Invalid')
        
    df['AM/PM'] = df_am_arr
    
    df['Weekend or not'] = df['day_of_week'].map({'Saturday': 'Yes',
                                              'Sunday': 'Yes',
                                              'Monday': 'No',
                                              'Tuesday': 'No',
                                              'Wednesday': 'No',
                                              'Thursday': 'No',
                                              'Friday': 'No'})
    
    df_lsoa_split = df['lsoa_of_accident_location'].str[2:]
    lsoa_residents_arr = []
    lsoa_households_arr = []
    for i in df_lsoa_split.iteritems():
        if i[1] != '-1':
            lsoa_residents_arr.append(i[1][0:4])
            lsoa_households_arr.append(i[1][4:])
        else:
            lsoa_residents_arr.append('-1')
            lsoa_households_arr.append('-1')
    
    df['number_of_residents'] = lsoa_residents_arr
    df['number_of_households'] = lsoa_households_arr
    
    ti.xcom_push(key='cleaned_transformed_data', value=df.to_json())
    
    
def load_cleaned_data(ti):
    x = ti.xcom_pull(task_ids='clean_transform_data', key='cleaned_transformed_data')
    df = pd.read_json(x)
    #df = df.to_csv()
    df.to_csv('/opt/airflow/Processed-data-files/2013_Aciidents_UK_Preprocessed.csv')
    
    
def extract_additional_resources(ti):
    df2 = pd.read_csv('/opt/airflow/2013/Vehicle_Information.csv', encoding= 'unicode_escape')
    df2 = df2[df2['Year'] == 2013]
    df2_required = df2[['Accident_Index', 'Age_Band_of_Driver']]
    df2_required = df2_required.drop_duplicates(subset='Accident_Index', keep=False)
    df2_required.set_index('Accident_Index')
    ti.xcom_push(key='data_for_integration', value=df2_required.to_json())
    
    
def integrate_load(ti):
    x = ti.xcom_pull(task_ids='clean_transform_data', key='cleaned_transformed_data')
    
    df = pd.read_json(x)
    df.set_index('accident_index')
    #df = df.to_csv()
    
    y = ti.xcom_pull(task_ids='extract_additional_resources', key='data_for_integration')
    
    df2_required = pd.read_json(y)
    df2_required.set_index('Accident_Index')
    #df2_required = df2_required.to_csv()
    
    df3 = pd.merge(df, df2_required, how="inner", left_on="accident_index", right_on="Accident_Index")
    df3.set_index('Accident_Index')
    df3.drop(['accident_year'], axis=1, inplace=True)
    df3['Age_Band_of_Driver'].replace('Data missing or out of range', np.nan, inplace=True)
    percentage_nan_age = (df3['Age_Band_of_Driver'].isna().sum()/df3.shape[0]) * 100
    df3.dropna(subset=['Age_Band_of_Driver'], inplace=True)
    lbl_encoder = LabelEncoder()
    df3['Age_Band_of_Driver'] = lbl_encoder.fit_transform(df3['Age_Band_of_Driver'])
    df3['Age_Band_of_Driver'] = df3['Age_Band_of_Driver'].astype(int)
    df3.to_csv('/opt/airflow/Processed-data-files/2013_Aciidents_UK_Last.csv')
    

default_args = {
    'owner': 'Team-2',
    'retries': 5,
    'retry_delay': timedelta(minutes=5),
    'start_date': datetime.datetime(2023, 1, 17)
}

with DAG(
    default_args=default_args,
    dag_id='DE-Milestone-3-3-3',
    description='Milestone 3 for DE project',
    schedule_interval='@once'
) as dag:

    task1 = PythonOperator(
        task_id='read_csv_file', 
        python_callable=read_csv_file
    )
    
    task2 = PythonOperator(
        task_id='clean_transform_data',
        python_callable=clean_transform_data
    )
    
    task3 = PythonOperator(
        task_id='load_cleaned_data', 
        python_callable=load_cleaned_data
    )
    
    task4 = PythonOperator(
        task_id='extract_additional_resources', 
        python_callable=extract_additional_resources
    )
    
    task5 = PythonOperator(
        task_id='integrate_load', 
        python_callable=integrate_load
    )
    
    task1 >> task2 >> task3 >> task4 >> task5